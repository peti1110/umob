<?php

namespace MetzWeb\Instagram;

class InstagramException extends \Exception
{
}
