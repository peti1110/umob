<?php
die('Access denied!');