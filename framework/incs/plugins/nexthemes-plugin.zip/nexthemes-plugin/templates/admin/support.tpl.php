<?php
/**
 * Package: TheShopier.
 * User: kinhdon
 * Date: 1/31/2016
 * Vertion: 1.0
 */

?>

<div class="wrap about-wrap nexthemes-wrap">

    <?php do_action('nth_plugin_panel_header');?>

    <div class="nav-tab-conent">
        <?php
        NexThemes_Plg::getImage(array(
            'src'   => 'http://nexthemes.com/desc/wp/theshopier/main_item2.png',
            'alt'   => 'Documentation image',
            'before'    => '<a target="_blank" href="//demo.nexthemes.com/wordpress/theshopier/documentation/">',
            'after'     => '</a>'
        ));
        ?>
    </div>

</div>
