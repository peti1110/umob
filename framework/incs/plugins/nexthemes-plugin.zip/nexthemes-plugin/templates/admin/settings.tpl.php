<?php
/**
 * Package: TheShopier.
 * User: kinhdon
 * Date: 1/31/2016
 * Vertion: 1.0
 */

?>

<div class="wrap about-wrap nexthemes-wrap">

    <?php do_action('nth_plugin_panel_header');?>

    <div class="nav-tab-conent">
        <?php
        $settings_api->show_navigation();
        $settings_api->show_forms();
        ?>

    </div>

</div>
